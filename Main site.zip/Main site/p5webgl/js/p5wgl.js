var w = 800;
var h = 600;

function setup() {
  createCanvas(w, h, WEBGL);
}

function draw() {
  background(51);

  fill(255, 0, 150);
  rect(0, 0, 50, 50);
}
