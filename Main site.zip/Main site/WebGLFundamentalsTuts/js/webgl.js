var canv = document.getElementById('c');
var ctx = canv.getContext('WebGL');
